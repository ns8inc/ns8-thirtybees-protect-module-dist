/**
 *  @author    NS8.com <support@ns8.com>
 *  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  @copyright 2018 NS8.com
 */
var NS8Page = {
    showAlert: function(msg) {
        alert(msg);
    }
};
